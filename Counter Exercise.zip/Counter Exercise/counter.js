const inputNumber = document.getElementById("counter-number");
const addBtn = document.getElementById("increase-btn");
const resetBtn = document.getElementById("reset-btn");
const minusBtn = document.getElementById("decrease-btn");
const displayNumber = document.getElementById("display-number");

let count = 0;
function currentNumber() {
  displayNumber.textContent = count;
}

inputNumber.addEventListener("input", function () {
  let number = parseInt(inputNumber.value) || 0;
  count = number;
});

addBtn.addEventListener("click", function () {
  count++;
  currentNumber();
});

resetBtn.addEventListener("click", function () {
  count = 0;
  inputNumber.value = count;
  currentNumber();
});

minusBtn.addEventListener("click", function () {
  count--;
  currentNumber();
});
currentNumber();
